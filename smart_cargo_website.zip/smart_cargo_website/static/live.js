
/*
 SMART CARGO - LIVE.JS
 STM32F103 + ESP-01 + FLASK
 Fast live monitoring - 500ms polling
 Existing HTML and CSS unchanged
*/

(() => {
    "use strict";

    const $ = id => document.getElementById(id);

    const REFRESH_MS = 500;
    const LIMIT_DEFAULT = 60;
    const MAX_GRAPH_POINTS = 100;
    const MAX_EVENTS = 14;

    let busy = false;
    let lastSignature = "";
    let graphHistory = [];
    let graphLimit = LIMIT_DEFAULT;

    // =========================================
    // HELPERS
    // =========================================

    function setText(id, value) {
        const el = $(id);
        if (el) el.textContent = String(value);
    }

    function num(value) {
        if (value === null ||
            value === undefined ||
            value === "") return null;

        const n = Number(value);
        return Number.isFinite(n) ? n : null;
    }

    function kg(value, digits = 3) {
        return value === null
            ? "-- kg"
            : Number(value).toFixed(digits) + " kg";
    }

    function setChip(id, label, state) {
        const el = $(id);
        if (!el) return;

        el.textContent = label;
        el.className =
            (id === "load-state"
                ? "state-chip "
                : "status-chip ") + state;
    }

    function normalizeHistory(raw) {
        if (!Array.isArray(raw)) return [];

        return raw.map(r => {
            if (!r || typeof r !== "object") {
                return null;
            }

            const weight = num(r.weight);
            if (weight === null) return null;

            return {
                weight,
                overload: r.overload === true,
                relay: r.relay === true,
                timestamp: String(r.timestamp || "--"),
                epoch: num(r.epoch)
            };
        }).filter(Boolean);
    }

    // =========================================
    // LIVE WEIGHT GRAPH
    // =========================================

    function drawChart(records, limit) {
        const canvas = $("weight-chart");
        if (!canvas) return;

        const ctx = canvas.getContext("2d");
        if (!ctx) return;

        const bounds = canvas.getBoundingClientRect();

        const width = Math.max(270, bounds.width);
        const height = Math.max(200, bounds.height);

        const dpr = Math.min(
            window.devicePixelRatio || 1,
            2
        );

        canvas.width = Math.round(width * dpr);
        canvas.height = Math.round(height * dpr);

        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        ctx.clearRect(0, 0, width, height);

        const L = 50;
        const R = 16;
        const T = 22;
        const B = 36;

        const gw = width - L - R;
        const gh = height - T - B;

        const values = records.map(r => r.weight);

        const minValue = Math.min(0, ...values);
        const maxValue = Math.max(
            limit * 1.25,
            20,
            ...values
        );

        const low = minValue < 0
            ? Math.floor((minValue - 5) / 10) * 10
            : 0;

        const high = Math.ceil(
            (maxValue + 5) / 10
        ) * 10;

        const x = i => L + (
            records.length <= 1
                ? gw / 2
                : i * gw / (records.length - 1)
        );

        const y = value =>
            T + gh * (high - value) / (high - low);

        // GRID

        ctx.font = "11px Consolas, monospace";
        ctx.textAlign = "right";
        ctx.textBaseline = "middle";

        for (let i = 0; i <= 4; i++) {
            const value =
                low + (high - low) * i / 4;

            const yy = y(value);

            ctx.beginPath();
            ctx.strokeStyle = "#263c51";
            ctx.lineWidth = 1;
            ctx.moveTo(L, yy);
            ctx.lineTo(width - R, yy);
            ctx.stroke();

            ctx.fillStyle = "#839eb5";
            ctx.fillText(
                value.toFixed(0),
                L - 8,
                yy
            );
        }

        // 60 KG OVERLOAD LIMIT

        if (limit >= low && limit <= high) {
            ctx.beginPath();
            ctx.setLineDash([6, 5]);
            ctx.strokeStyle = "#ff5269";

            ctx.moveTo(L, y(limit));
            ctx.lineTo(width - R, y(limit));
            ctx.stroke();

            ctx.setLineDash([]);

            ctx.fillStyle = "#ff9da9";
            ctx.textAlign = "left";

            ctx.fillText(
                limit.toFixed(0) + " kg limit",
                L + 8,
                Math.max(10, y(limit) - 10)
            );
        }

        if (!records.length) {
            ctx.fillStyle = "#93adc2";
            ctx.textAlign = "center";
            ctx.font = "13px Arial";

            ctx.fillText(
                "Waiting for real telemetry history...",
                width / 2,
                height / 2
            );
            return;
        }

        // GRAPH FILL

        if (records.length > 1) {
            const gradient =
                ctx.createLinearGradient(
                    0, T,
                    0, height - B
                );

            gradient.addColorStop(
                0,
                "rgba(67,224,194,0.24)"
            );

            gradient.addColorStop(
                1,
                "rgba(67,224,194,0.015)"
            );

            ctx.beginPath();

            records.forEach((r, i) => {
                if (i === 0) {
                    ctx.moveTo(x(i), y(r.weight));
                } else {
                    ctx.lineTo(x(i), y(r.weight));
                }
            });

            ctx.lineTo(
                x(records.length - 1),
                y(low)
            );

            ctx.lineTo(x(0), y(low));
            ctx.closePath();

            ctx.fillStyle = gradient;
            ctx.fill();

            // LIVE LINE

            ctx.beginPath();

            records.forEach((r, i) => {
                if (i === 0) {
                    ctx.moveTo(x(i), y(r.weight));
                } else {
                    ctx.lineTo(x(i), y(r.weight));
                }
            });

            ctx.strokeStyle = "#43e0c2";
            ctx.lineWidth = 2.5;
            ctx.lineJoin = "round";
            ctx.stroke();
        }

        // LATEST POINT

        const last = records.length - 1;

        ctx.beginPath();

        ctx.arc(
            x(last),
            y(records[last].weight),
            4.5,
            0,
            Math.PI * 2
        );

        ctx.fillStyle = records[last].overload
            ? "#ff5269"
            : "#43e0c2";

        ctx.fill();

        // TIME LABELS

        ctx.fillStyle = "#819aaf";
        ctx.font = "10px Consolas, monospace";
        ctx.textBaseline = "alphabetic";

        ctx.textAlign = "left";
        ctx.fillText(
            records[0].timestamp,
            L,
            height - 7
        );

        ctx.textAlign = "right";
        ctx.fillText(
            records[last].timestamp,
            width - R,
            height - 7
        );
    }

    // =========================================
    // ACTIVITY TABLE
    // =========================================

    function updateActivity(records) {
        const tbody = $("events");
        if (!tbody) return;

        tbody.replaceChildren();

        const recent = records.slice(-MAX_EVENTS);

        setText(
            "event-count",
            recent.length + " records"
        );

        if (!recent.length) {
            const tr = document.createElement("tr");
            const td = document.createElement("td");

            td.colSpan = 4;
            td.className = "placeholder";
            td.textContent =
                "No telemetry received yet.";

            tr.appendChild(td);
            tbody.appendChild(tr);
            return;
        }

        for (let i = recent.length - 1; i >= 0; i--) {
            const r = recent[i];

            const index =
                records.length - recent.length + i;

            const prev = index > 0
                ? records[index - 1]
                : null;

            let event = "Weight reading received";

            if (r.overload &&
                (!prev || !prev.overload)) {
                event = "Overload detected";
            } else if (
                !r.overload &&
                prev &&
                prev.overload
            ) {
                event = "Overload cleared";
            } else if (
                r.relay &&
                (!prev || !prev.relay)
            ) {
                event = "Relay cutoff activated";
            } else if (
                !r.relay &&
                prev &&
                prev.relay
            ) {
                event = "Relay cutoff released";
            } else if (r.overload) {
                event = "Overload reading received";
            }

            const tr = document.createElement("tr");

            [
                r.timestamp,
                event,
                kg(r.weight)
            ].forEach(value => {
                const td = document.createElement("td");
                td.textContent = value;
                tr.appendChild(td);
            });

            const statusCell =
                document.createElement("td");

            const badge =
                document.createElement("span");

            badge.className =
                "table-status " +
                (r.overload ? "danger" : "safe");

            badge.textContent =
                r.overload ? "OVERLOAD" : "NORMAL";

            statusCell.appendChild(badge);
            tr.appendChild(statusCell);
            tbody.appendChild(tr);
        }
    }

    // =========================================
    // UPDATE COMPLETE DASHBOARD
    // =========================================

    function updateDashboard(data) {
        const latest =
            data.latest &&
            typeof data.latest === "object"
                ? data.latest
                : null;

        const rawLimit = num(data.limit);

        const limit =
            rawLimit !== null && rawLimit > 0
                ? rawLimit
                : LIMIT_DEFAULT;

        const weight = latest
            ? num(latest.weight)
            : null;

        const hasData = weight !== null;
        const online = data.online === true;

        const overload = hasData &&
            (latest.overload === true ||
             weight > limit);

        const relay =
            hasData && latest.relay === true;

        const history =
            normalizeHistory(data.history);

        const stats = data.stats || {};

        // STATISTICS

        setText(
            "packet-count",
            num(stats.total_packets) ??
                history.length
        );

        setText(
            "avg-weight",
            kg(num(stats.avg_weight), 2)
        );

        setText(
            "peak-weight",
            kg(num(stats.peak_weight), 2)
        );

        setText(
            "sample-count",
            history.length + " samples"
        );

        setText(
            "capacity-label",
            "Limit: " + kg(limit, 0)
        );

        setText(
            "gauge-limit",
            limit.toFixed(0)
        );

        setText(
            "last-packet",
            latest
                ? String(latest.timestamp || "Recorded")
                : "Never"
        );

        setText(
            "stm32-detail",
            latest
                ? String(latest.timestamp || "Received")
                : "Never"
        );

        const hazardBanner = $("hazard-banner");

        if (hasData) {
            const percent =
                (weight / limit) * 100;

            const clamped = Math.max(
                0,
                Math.min(100, percent)
            );

            // LIVE WEIGHT

            setText("weight", kg(weight));

            setText(
                "gauge-weight",
                weight.toFixed(3)
            );

            setText(
                "truck-weight-label",
                kg(weight)
            );

            setText(
                "utilization-text",
                percent.toFixed(1) + "%"
            );

            // PROGRESS BAR

            const progress = $("progress");

            if (progress) {
                progress.style.width =
                    clamped + "%";

                progress.style.background =
                    overload
                        ? "#ff5269"
                        : "linear-gradient(90deg,#0098af,#43e0c2)";
            }

            // TRUCK CARGO VISUALIZATION

            const cargo = $("truck-cargo-fill");

            if (cargo) {
                const cargoHeight =
                    116 * clamped / 100;

                cargo.setAttribute(
                    "y",
                    (177 - cargoHeight).toFixed(1)
                );

                cargo.setAttribute(
                    "height",
                    cargoHeight.toFixed(1)
                );

                cargo.setAttribute(
                    "fill",
                    overload
                        ? "#ff5269"
                        : "url(#cargoFill)"
                );
            }

            // CIRCULAR GAUGE

            const arc = $("gauge-arc");

            if (arc) {
                arc.setAttribute(
                    "stroke-dasharray",
                    clamped.toFixed(1) + " 100"
                );

                arc.setAttribute(
                    "stroke",
                    overload
                        ? "#ff5269"
                        : "#43e0c2"
                );
            }

            // OVERLOAD STATUS

            setText(
                "overload",
                overload ? "OVERLOAD" : "NORMAL"
            );

            const overloadEl = $("overload");

            if (overloadEl) {
                overloadEl.className =
                    "metric-value " +
                    (overload ? "danger" : "safe");
            }

            setText(
                "overload-message",
                overload
                    ? "Cargo exceeds " + kg(limit, 0)
                    : "Within configured load limit"
            );

            setChip(
                "load-state",
                overload
                    ? "OVERLOADED"
                    : "WITHIN LIMIT",
                overload ? "danger" : "safe"
            );

            // RELAY STATUS

            setText(
                "relay-status",
                relay
                    ? "CUTOFF ACTIVE"
                    : "NORMAL / RUN"
            );

            const relayEl = $("relay-status");

            if (relayEl) {
                relayEl.className =
                    "metric-value " +
                    (relay ? "danger" : "safe");
            }

            setText(
                "relay-message",
                relay
                    ? "PB0 relay reported ON"
                    : "PB0 relay reported OFF"
            );

            // OVERLOAD WARNING

            if (hazardBanner) {
                hazardBanner.classList.toggle(
                    "hidden",
                    !overload
                );

                setText(
                    "hazard-weight",
                    kg(weight)
                );

                const message =
                    hazardBanner.querySelector("span");

                if (message) {
                    message.textContent = online
                        ? "Live weight exceeds configured limit."
                        : "Last reading exceeded limit; telemetry stale.";
                }
            }

        } else {
            setText("weight", "-- kg");
            setText("gauge-weight", "--");
            setText("truck-weight-label", "-- kg");
            setText("utilization-text", "--%");
            setText("overload", "WAITING");
            setText("overload-message", "Waiting for data");
            setText("relay-status", "UNKNOWN");
            setText("relay-message", "No relay data");

            setChip(
                "load-state",
                "NO READING",
                "neutral"
            );

            if ($("progress")) {
                $("progress").style.width = "0%";
            }

            if ($("gauge-arc")) {
                $("gauge-arc").setAttribute(
                    "stroke-dasharray",
                    "0 100"
                );
            }

            if ($("truck-cargo-fill")) {
                $("truck-cargo-fill").setAttribute(
                    "height",
                    "0"
                );
            }

            if (hazardBanner) {
                hazardBanner.classList.add("hidden");
            }
        }

        // =====================================
        // CONNECTION STATUS
        // =====================================

        const connection = $("connection-pill");

        if (connection) {
            connection.className =
                "connection-pill " +
                (online ? "online" : "offline");
        }

        setText(
            "connection-text",
            online
                ? "TELEMETRY LIVE"
                : hasData
                    ? "TELEMETRY STALE"
                    : "WAITING FOR DEVICE"
        );

        setText(
            "data-mode",
            online
                ? "HARDWARE FEED · LIVE"
                : hasData
                    ? "LAST KNOWN DATA"
                    : "NO TELEMETRY"
        );

        setText(
            "telemetry-status",
            online
                ? "LIVE"
                : hasData
                    ? "STALE"
                    : "WAITING"
        );

        const telemetry = $("telemetry-status");

        if (telemetry) {
            telemetry.className =
                "metric-value " +
                (online ? "safe" : "muted");
        }

        setText(
            "telemetry-message",
            online
                ? "Recent telemetry received"
                : hasData
                    ? "No recent packets received"
                    : "Waiting for first measurement"
        );

        setText(
            "notice",
            online
                ? "Receiving live STM32 telemetry. Weight, gauge and graph are updating."
                : hasData
                    ? "Flask is online, but device telemetry is stale. Showing last known reading."
                    : "Flask is online. Waiting for POST /api/weight."
        );

        setChip(
            "stm32-status",
            online
                ? "REPORTING"
                : hasData
                    ? "NO RECENT DATA"
                    : "UNVERIFIED",
            online ? "safe" : "neutral"
        );

        setChip(
            "esp-status",
            online
                ? "LINK INFERRED"
                : "UNVERIFIED",
            online ? "safe" : "neutral"
        );

        setText(
            "esp-detail",
            online
                ? "Telemetry path active"
                : "No independent Wi-Fi status"
        );

        // =====================================
        // UPDATE GRAPH WHEN DATA CHANGES
        // =====================================

        const first = history[0];
        const last = history[history.length - 1];

        const signature = [
            history.length,
            first
                ? first.epoch ?? first.timestamp
                : "",
            last
                ? last.epoch ?? last.timestamp
                : "",
            last ? last.weight : "",
            num(stats.total_packets) ?? ""
        ].join("|");

        if (
            signature !== lastSignature ||
            graphLimit !== limit
        ) {
            lastSignature = signature;
            graphLimit = limit;

            graphHistory =
                history.slice(-MAX_GRAPH_POINTS);

            drawChart(graphHistory, limit);
            updateActivity(history);
        }
    }

    // =========================================
    // FAST LIVE DATA FETCH
    // =========================================

    async function poll() {
        if (busy) return;

        busy = true;

        try {
            const response = await fetch(
                "/api/live?t=" + Date.now(),
                {
                    method: "GET",
                    cache: "no-store"
                }
            );

            if (!response.ok) {
                throw new Error(
                    "HTTP " + response.status
                );
            }

            const data = await response.json();

            updateDashboard(data);

            setChip(
                "flask-status",
                "ONLINE",
                "safe"
            );

            setText(
                "flask-detail",
                "API response " +
                new Date().toLocaleTimeString()
            );

        } catch (error) {
            console.error(
                "Smart Cargo polling error:",
                error
            );

            setChip(
                "flask-status",
                "OFFLINE",
                "danger"
            );

            setText(
                "flask-detail",
                "API request failed"
            );

            setText(
                "notice",
                "Flask connection error: " +
                error.message
            );

            const pill = $("connection-pill");

            if (pill) {
                pill.className =
                    "connection-pill offline";
            }

            setText(
                "connection-text",
                "API OFFLINE"
            );

        } finally {
            busy = false;
        }
    }

    // =========================================
    // START LIVE MONITORING
    // =========================================

    function start() {
        // First update immediately
        poll();

        // Repeat every 500 milliseconds
        setInterval(poll, REFRESH_MS);

        // Dashboard clock
        const clock = $("clock");

        if (clock) {
            const updateClock = () => {
                clock.textContent =
                    new Date().toLocaleTimeString();
            };

            updateClock();

            setInterval(updateClock, 1000);
        }

        // Responsive graph
        window.addEventListener(
            "resize",
            () => {
                drawChart(
                    graphHistory,
                    graphLimit
                );
            }
        );
    }

    if (document.readyState === "loading") {
        document.addEventListener(
            "DOMContentLoaded",
            start
        );
    } else {
        start();
    }

})();
